#define SQLITE_CORE
#include <R_ext/Visibility.h>
#include "vendor/sqlite3/regexp.c"
