library(testthat)
library(RSQLite)

test_check("RSQLite")
